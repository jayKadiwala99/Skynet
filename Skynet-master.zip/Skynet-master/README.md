# Skynet
This is the project that me and my team have been working in the summer of 2020. This is a service providing web application.
